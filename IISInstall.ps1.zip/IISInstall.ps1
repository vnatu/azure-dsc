Configuration IISInstall
{
    Node localhost
    {
        WindowsFeature IIS 
        {
            Name = "web-server"
            Ensure = "Present"
        }
        #Install ASP.NET 4.5
        WindowsFeature ASPNET45
        {
            Ensure = "Present"
            Name="web-Asp-Net45"
        }
    }
}